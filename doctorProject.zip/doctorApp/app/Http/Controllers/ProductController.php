<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use App\Models\Product;
use App\Models\Sitesetting;
use Contacts;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use App\Models\Sociallink;
use Cohensive\Embed\Facades\Embed;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $banners = Sitesetting::all();
        $products = Product::all();
        $links = Sociallink::all();

        // dd($embed);
        // echo "<pre>"; print_r($embed) ;
        // die;
        return view('index', compact('banners', 'products', 'links'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.add-product');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'description' => 'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        $input = $request->all();

        if ($image = $request->file('image')) {
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $destinationPath = public_path('product/images');
            if (!Storage::exists($destinationPath)) {
                Storage::makeDirectory($destinationPath, 0775, true, true);
            }
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$profileImage";
        }

        Product::create($input);

        return redirect()->route('admin.index')
            ->with('success', 'Product added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        return view('products.show', compact('product'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        return view('admin.edit-product', compact('product'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'description' => 'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        $input = $request->all();

        if ($image = $request->file('image')) {
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $destinationPath = public_path('product/images');
            if (!Storage::exists($destinationPath)) {
                Storage::makeDirectory($destinationPath, 0775, true, true);
            }
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$profileImage";
        } else {
            unset($input['image']);
        }

        $product->update($input);

        return redirect()->route('admin.index')
            ->with('success', 'Product updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        $product->delete();

        return redirect()->route('admin.index')
            ->with('success', 'Product deleted successfully');
    }

    /*
     * Get about page info.
     */
    public function about()
    {
        return view('about');
    }
    /*
     * Get product page info.
     */
    public function products()
    {
        $products = Product::all();
        return view('product.index', compact('products'));
    }
    /*
     * Get contact page info.
     */
    public function contact()
    {
        return view('contact');
    }
    /**
     * Submit contact info.
     *
     * @param  \Illuminate\Http\Request  $request
     */
    public function submitContactInfo(Request $request)
    {
        // echo "<pre>"; print_r($request->all()); die;
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email|unique:contacts',
            'phone' => 'required|numeric|digits:10',
            'message' => 'required',
        ]);
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }
        $input = $request->all();
        Contact::create($input);

        return redirect()->back()->with('success', 'Information sent successfully');
    }
}
