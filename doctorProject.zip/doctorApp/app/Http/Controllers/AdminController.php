<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\Contact;
use App\Models\Product;
use App\Models\Sitesetting;
use App\Models\Sociallink;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $products = Product::latest()->paginate(5);

        return view('admin.index', compact('products'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
        // return view('admin.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }


    public function addProduct()
    {
        return view('admin.add-product');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function show(Admin $admin)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function edit(Admin $admin)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Admin $admin)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function destroy(Admin $admin)
    {
        //
    }
    public function siteSetting(Request $request)
    {
        //
        return view('admin.site-setting');
    }
    public function storeSiteSetting(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'banner' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:5048',
        ]);
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        $input = $request->all();

        if ($image = $request->file('banner')) {
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $destinationPath = public_path('banner');
            if (!Storage::exists($destinationPath)) {
                Storage::makeDirectory($destinationPath, 0775, true, true);
            }
            $image->move($destinationPath, $profileImage);
            $input['banner'] = "$profileImage";
        }

        Sitesetting::create($input);

        return redirect()->back()->with('success', 'Banner added successfully');
    }
    public function showMessage()
    {
        $messages = Contact::paginate(4);
        return view('admin.user-message', compact('messages'))->with('i', (request()->input('page', 1) - 1) * 5);
    }
    public function deleteMessage($id)
    {
        $message = Contact::find($id);
        $message->delete();
        return redirect()->back()->with('success', 'Message deleted successfully');
    }

    public function showSiteBanner()
    {
        $messages = Sitesetting::all();
        return view('admin.view-site-setting', compact('messages'));
    }
    public function deleteBanner($id)
    {
        $message = Sitesetting::find($id);
        $message->delete();
        return redirect()->back()->with('success', 'Banner deleted successfully');
    }
    public function deleteLink($id)
    {
        $message = Sociallink::find($id);
        $message->delete();
        return redirect()->back()->with('success', 'Link deleted successfully');
    }

    public function storeLink(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'youtube' => 'required',

        ]);
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        $input = $request->all();
        Sociallink::create($input);

        return redirect()->back()->with('success', 'Link added successfully');
    }
}
