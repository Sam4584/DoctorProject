<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\ProductController;
use App\Models\Sociallink;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [ProductController::class, 'index'])->name('home');

Route::get('/admin-index', [AdminController::class, 'index'])->name('admin.index');
Route::get('/add-product', [AdminController::class, 'addProduct'])->name('add.product');
Route::get('/site-setting', [AdminController::class, 'siteSetting'])->name('site.setting');
Route::post('/site-setting-store', [AdminController::class, 'siteSetting'])->name('site.setting.store');
Route::post('/store-product-detail', [AdminController::class, 'storeSiteSetting'])->name('store.product.detail');
Route::get('/user-message', [AdminController::class, 'showMessage'])->name('user.message');
Route::get('/delete-message/{id?}', [AdminController::class, 'deleteMessage'])->name('delete.message');
Route::get('/show-site-banner', [AdminController::class, 'showSiteBanner'])->name('show.site.banner');
Route::get('/delete-banner/{id?}', [AdminController::class, 'deleteBanner'])->name('delete.banner');
Route::get('/link/{id?}', [AdminController::class, 'deleteLink'])->name('delete.link');
Route::get('/youtube-link', function () {
    return view('admin.add-link');
});
Route::get('/view-all-links', function () {
    $links = Sociallink::all();
    return view('admin.view-all-links', compact('links'));
})->name('view.all.links');
Route::post('/store-link', [AdminController::class, 'storeLink'])->name('store.link');
Route::get('/about', [ProductController::class, 'about'])->name('about');
Route::get('/all-products', [ProductController::class, 'products'])->name('all.products');
Route::get('/contact-us', [ProductController::class, 'contact'])->name('contact.us');
Route::post('/submit-contact-info', [ProductController::class, 'submitContactInfo'])->name('submit.contact.info');
Route::resource('products', ProductController::class);
// Route::get('/post', 'ProductController@post')->name('/post');


