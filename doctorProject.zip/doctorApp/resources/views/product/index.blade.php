@extends('layouts.app')
@section('content')
<div id="protien" class="protien_main">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="titlepage">
                    <h2>Our Products</h2>
                </div>
            </div>
        </div>

        <div class="row">
            @foreach ($products as $product)
                <div class="col-md-6 col-sm-6">
                    <div class="protien">
                        {{-- <img src="/product/images/{{ $product->image }}" style="max-width: 200px;height: auto;" > --}}
                        <figure><img src="/product/images/{{ $product->image }}" alt="#"
                                style="border-radius: 25px;width: 400px;height: 220px;" />
                        </figure>
                        <span> {{ $product->name }} </span>

                        <p>
                            @if (strlen($product->description) > 50)
                                {{ substr($product->description, 0, 50) }}
                                <span class="read-more-show hide_content">More<i class="fa fa-angle-down"></i></span>
                                <span class="read-more-content">
                                    {{ substr($product->description, 50, strlen($product->description)) }}
                                    <span class="read-more-hide hide_content">Less <i class="fa fa-angle-up"></i></span>
                                </span>
                            @else
                                {{ $product->description }}
                            @endif
                        </p>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
@endsection
