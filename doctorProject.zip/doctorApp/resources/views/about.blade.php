@extends('layouts.app')
@section('content')
<!-- about -->
<div id="about" class="about">
    <div class="container-fluid">
        <div class="row d_flex">
            <div class="col-md-6">
                <div class="titlepage">
                    <h2>About Us</h2>
                    <p>It is a long established fact that a reader will be distracted by the readable content of a
                        page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or</p>
                    <a class="read_more" href="Javascript:void(0)"> Read More</a>
                </div>
            </div>
            <div class="col-md-6 pad_right0">
                <div class="about_img ">
                    <figure><img src="images/about.png" alt="#" /></figure>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end about -->
@endsection
