@extends('admin.layouts.app')
@section('content')
    <div class="container" style="margin-top:50px">


        @if (\Session::has('success'))
        <div class="alert alert-success">
            <ul>
                <li>{!! \Session::get('success') !!}</li>
            </ul>
        </div>
    @endif
        @if ($errors->any())
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class="pull-right" align='right' style="margin-bottom: 10px">
            <a class="btn btn-success" href="{{ route('view.all.links') }}">View All Links</a>
        </div>
        <form action="{{ route('store.link') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="row">

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>You-Tube Link:</strong>
                        <input type="text" name="youtube" class="form-control" placeholder="Add a youtube link here">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button  style="margin-top: 11px;" type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>

        </form>
    </div>
@endsection
