@extends('admin.layouts.app')
@section('content')

    <div class="row">
        <div class="container">
            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Message</th>
                    <th width="280px">Action</th>
                </tr>
                {{-- @php
                $i=1;
            @endphp --}}

                @foreach ($messages as $message)
                    <tr>
                        <td>{{++$i}}</td>

                        <td>{{ $message->name }}</td>
                        <td>{{ $message->email }}</td>
                        <td>{{ $message->phone }}</td>
                        <td>
                            {{-- {{ $message->message }} --}}
                            @if(strlen($message->message) > 50)
                            {{substr($message->message,0,50)}}
                            <span class="read-more-show hide_content">More<i class="fa fa-angle-down"></i></span>
                            <span class="read-more-content"> {{substr($message->message,50,strlen($message->message))}}
                            <span class="read-more-hide hide_content">Less <i class="fa fa-angle-up"></i></span> </span>
                        @else
                            {{$message->message}}
                        @endif

                        </td>
                        <td>
                            <a href="{{ route('delete.message', ['id' => $message->id]) }}"
                                onclick="return confirm('Do you want do delete this message')">
                                <button class="btn btn-danger">Delete</button>
                            </a>
                        </td>
                    </tr>
                @endforeach

            </table>
            {!! $messages->links() !!}
        </div>
        {{-- {!! $data->links() !!} --}}
    </div>

@endsection
