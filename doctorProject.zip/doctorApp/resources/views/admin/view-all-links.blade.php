
@extends('admin.layouts.app')
@section('content')
    <div class="row">
        <div class="container">
            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th>Banner</th>

                    <th width="280px">Action</th>
                </tr>
                @php
                    $i=1;
                @endphp
                @foreach ($links as $link)
                    <tr>
                        <td>{{$i++}}</td>
                        <td>{{ $link->youtube }}</td>
                        <td>
                            <a href="{{ route('delete.link', ['id' => $link->id]) }}"
                                onclick="return confirm('Do you want do delete this link')">
                                <button class="btn btn-danger">Delete</button>
                            </a>
                        </td>
                    </tr>
                @endforeach

            </table>

            {{-- {!! $messages->links() !!} --}}
        </div>
    </div>
@endsection
