@extends('admin.layouts.app')
@section('content')
    <div class="row">
        <div class="container">
            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th>Banner</th>

                    <th width="280px">Action</th>
                </tr>
                @php
                    $i=1;
                @endphp
                @foreach ($messages as $message)
                    <tr>
                        <td>{{$i++}}</td>
                        <td><img src="/banner/{{ $message->banner }}" width="100px"></td>
                        <td>
                            <a href="{{ route('delete.banner', ['id' => $message->id]) }}"
                                onclick="return confirm('Do you want do delete this message')">
                                <button class="btn btn-danger">Delete</button>
                            </a>
                        </td>
                    </tr>
                @endforeach

            </table>

            {{-- {!! $messages->links() !!} --}}
        </div>
    </div>
@endsection
