<style type="text/css">
    .read-more-show{
      cursor:pointer;
      color: #232ced;
    }
    .read-more-hide{
      cursor:pointer;
      color: #232ced;
    }

    .hide_content{
      display: none;
    }
</style>
 <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
          <a class="navbar-brand" href="{{route('admin.index')}}">Dashboard</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                      <a class="nav-link active" aria-current="page" href="/admin-index">Home</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="/add-product" >Add Product</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="/site-setting">Site Setting</a>
                  </li>
                  {{-- <li class="nav-item">
                      <a class="nav-link" href="/admin-admin-detail">Admin Details</a>
                  </li> --}}
                  <li class="nav-item">
                      <a class="nav-link" href="/user-message">Messages</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="/youtube-link">Add Youtube Links</a>
                  </li>


              </ul>
          </div>
      </div>
  </nav>
