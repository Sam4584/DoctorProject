<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script type="text/javascript">
        // Hide the extra content initially:
                    $('.read-more-content').addClass('hide_content')
                    $('.read-more-show, .read-more-hide').removeClass('hide_content')

                    // Set up the toggle effect:
                    $('.read-more-show').on('click', function(e) {
                      $(this).next('.read-more-content').removeClass('hide_content');
                      $(this).addClass('hide_content');
                      e.preventDefault();
                    });
                    $('.read-more-hide').on('click', function(e) {
                      var p = $(this).parent('.read-more-content');
                      p.addClass('hide_content');
                      p.prev('.read-more-show').removeClass('hide_content'); // Hide only the preceding "Read More"
                      e.preventDefault();
                    });
        </script>
