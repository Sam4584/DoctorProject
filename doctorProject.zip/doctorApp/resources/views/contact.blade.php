@extends('layouts.app')
@section('content')
    <!--  contact -->
    <div id="contact" class="contact">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="titlepage">
                        <h2>Request a call back</h2>
                    </div>
                </div>
            </div>
            @if (\Session::has('success'))
                <div class="alert alert-success">
                    <ul>
                        <li>{!! \Session::get('success') !!}</li>
                    </ul>
                </div>
            @endif
            @if ($errors->any())
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <form id="request" method="post" action="{{ route('submit.contact.info') }}">
                        @csrf
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="form-group">
                                    <strong>Name:</strong>
                                    <input class="form-control" placeholder="Full Name" type="type" name="name">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <strong>Email:</strong>
                                    <input class="form-control" placeholder="Email " type="email" name="email">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <strong>Phone:</strong>
                                    <input class="form-control" placeholder="Phone Number" type="text" name="phone">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <strong>Message:</strong>
                                    <textarea class="form-control" placeholder="Message" type="type" name="message"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" style="margin-top: 11px;" class="btn btn-primary">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- end contact -->
@endsection
