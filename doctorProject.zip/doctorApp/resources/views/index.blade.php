@extends('layouts.app')
@section('content')
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    @if (\Session::has('success'))
        <div class="alert alert-success">
            <ul>
                <li>{!! \Session::get('success') !!}</li>
            </ul>
        </div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <!-- header inner -->

    <div class="mt-6 mx-60 swiper mySwiper" style="height: 400px;">
        <div class="swiper-wrapper">

            @foreach ($banners as $banner)
                <div class="swiper-slide">
                    <img class="object-cover w-full h-full" src="/banner/{{ $banner->banner }}"
                        style="height: 100%;width: 100%;padding-left: 49px;padding-right: 50px;border-radius: 25px;">

                </div>
            @endforeach
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-pagination"></div>
    </div>

    <div id="protien" class="protien_main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="titlepage">
                        <h2>Our Products</h2>
                    </div>
                </div>
            </div>

            <div class="row">
                @foreach ($products as $product)
                    <div class="col-md-6 col-sm-6">
                        <div class="protien">
                            {{-- <img src="/product/images/{{ $product->image }}" style="max-width: 200px;height: auto;" > --}}
                            <figure><img src="/product/images/{{ $product->image }}" alt="#"
                                    style="border-radius: 25px;width: 400px;height: 220px;" />
                            </figure>
                            <span> {{ $product->name }} </span>

                            <p>
                                @if (strlen($product->description) > 50)
                                    {{ substr($product->description, 0, 50) }}
                                    <span class="read-more-show hide_content">More<i class="fa fa-angle-down"></i></span>
                                    <span class="read-more-content">
                                        {{ substr($product->description, 50, strlen($product->description)) }}
                                        <span class="read-more-hide hide_content">Less <i class="fa fa-angle-up"></i></span>
                                    </span>
                                @else
                                    {{ $product->description }}
                                @endif
                            </p>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
    <!-- end our protien  -->
    <!-- about -->
    <div id="about" class="about">
        <div class="container-fluid">
            <div class="row d_flex">
                <div class="col-md-6">
                    <div class="titlepage">
                        <h2>About Us</h2>
                        <p>It is a long established fact that a reader will be distracted by the readable content of a
                            page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or</p>
                        <a class="read_more" href="Javascript:void(0)"> Read More</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- end about -->

    <!-- testimonial -->
    <div id="testimonial" class="testimonial">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="titlepage">
                        <h2>Why Choose Us?</h2>
                    </div>
                </div>
            </div>
            <?php
            $arr = [];
            foreach ($links as $value) {
                $arr = $value->youtube;
                $embed = Embed::make($arr)->parseUrl();
                $embed->setAttribute(['width' => 600]);
                $youTubeLinks = $embed->getHtml();


            ?>
            <div class="row">
                {{-- @foreach ($youTubeLinks as $link) --}}
                <div class="col-md-8">
                    <div class="body_blu_img">

            <?php  echo $youTubeLinks; ?>
                    </div>
                </div>
                {{-- @endforeach --}}
            </div>
            <?php } ?>
        </div>
    </div>
    <!-- end testimonial -->
    <!--  contact -->
    <div id="contact" class="contact">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="titlepage">
                        <h2>Request a call back</h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <form id="request" method="post" action="{{ route('submit.contact.info') }}">
                        @csrf
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="form-group">
                                    <strong>Name:</strong>
                                    <input class="form-control" placeholder="Full Name" type="type" name="name">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <strong>Email:</strong>
                                    <input class="form-control" placeholder="Email " type="email" name="email">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <strong>Phone:</strong>
                                    <input class="form-control" placeholder="Phone Number" type="text" name="phone">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <strong>Message:</strong>
                                    <textarea class="form-control" placeholder="Message" type="type" name="message"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" style="margin-top: 11px;" class="btn btn-primary">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- end contact -->
    <!--  footer -->
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    <script>
        var swiper = new Swiper(".mySwiper", {
            cssMode: true,
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
            pagination: {
                el: ".swiper-pagination",
            },
            mousewheel: true,
            keyboard: true,
        });
    </script>

@endsection
