<?php $__env->startSection('content'); ?>
<div id="protien" class="protien_main">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="titlepage">
                    <h2>Our Products</h2>
                </div>
            </div>
        </div>

        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-sm-6">
                    <div class="protien">
                        
                        <figure><img src="/product/images/<?php echo e($product->image); ?>" alt="#"
                                style="border-radius: 25px;width: 400px;height: 220px;" />
                        </figure>
                        <span> <?php echo e($product->name); ?> </span>

                        <p>
                            <?php if(strlen($product->description) > 50): ?>
                                <?php echo e(substr($product->description, 0, 50)); ?>

                                <span class="read-more-show hide_content">More<i class="fa fa-angle-down"></i></span>
                                <span class="read-more-content">
                                    <?php echo e(substr($product->description, 50, strlen($product->description))); ?>

                                    <span class="read-more-hide hide_content">Less <i class="fa fa-angle-up"></i></span>
                                </span>
                            <?php else: ?>
                                <?php echo e($product->description); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\doctorApp\resources\views/product/index.blade.php ENDPATH**/ ?>