<footer>
    <div class="footer">
        <div class="daih_bg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <ul class="conta">
                            <li><i class="fa fa-phone" aria-hidden="true"></i> Call Now +01 123467890</li>
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i> Location</li>
                            <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="#">
                                    demo@gmail.com</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
        
    </div>
</footer>
<!-- end footer -->
<!-- Javascript files-->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<script>
    function openNav() {
        document.getElementById("myNav").style.width = "100%";
    }

    function closeNav() {
        document.getElementById("myNav").style.width = "0%";
    }
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script type="text/javascript">
        // Hide the extra content initially:
                    $('.read-more-content').addClass('hide_content')
                    $('.read-more-show, .read-more-hide').removeClass('hide_content')

                    // Set up the toggle effect:
                    $('.read-more-show').on('click', function(e) {
                      $(this).next('.read-more-content').removeClass('hide_content');
                      $(this).addClass('hide_content');
                      e.preventDefault();
                    });
                    $('.read-more-hide').on('click', function(e) {
                      var p = $(this).parent('.read-more-content');
                      p.addClass('hide_content');
                      p.prev('.read-more-show').removeClass('hide_content'); // Hide only the preceding "Read More"
                      e.preventDefault();
                    });
        </script>
<?php /**PATH C:\wamp64\www\doctorApp\resources\views/layouts/footer.blade.php ENDPATH**/ ?>