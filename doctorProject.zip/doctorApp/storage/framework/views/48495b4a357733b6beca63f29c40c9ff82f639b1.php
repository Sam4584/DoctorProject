<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="container">
            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Message</th>
                    <th width="280px">Action</th>
                </tr>
                

                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$i); ?></td>

                        <td><?php echo e($message->name); ?></td>
                        <td><?php echo e($message->email); ?></td>
                        <td><?php echo e($message->phone); ?></td>
                        <td>
                            
                            <?php if(strlen($message->message) > 50): ?>
                            <?php echo e(substr($message->message,0,50)); ?>

                            <span class="read-more-show hide_content">More<i class="fa fa-angle-down"></i></span>
                            <span class="read-more-content"> <?php echo e(substr($message->message,50,strlen($message->message))); ?>

                            <span class="read-more-hide hide_content">Less <i class="fa fa-angle-up"></i></span> </span>
                        <?php else: ?>
                            <?php echo e($message->message); ?>

                        <?php endif; ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('delete.message', ['id' => $message->id])); ?>"
                                onclick="return confirm('Do you want do delete this message')">
                                <button class="btn btn-danger">Delete</button>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
            <?php echo $messages->links(); ?>

        </div>
        
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\doctorApp\resources\views/admin/user-message.blade.php ENDPATH**/ ?>