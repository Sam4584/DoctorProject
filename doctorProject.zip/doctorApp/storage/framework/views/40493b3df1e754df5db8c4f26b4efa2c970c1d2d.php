<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th>Banner</th>

                    <th width="280px">Action</th>
                </tr>
                <?php
                    $i=1;
                ?>
                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($link->youtube); ?></td>
                        <td>
                            <a href="<?php echo e(route('delete.link', ['id' => $link->id])); ?>"
                                onclick="return confirm('Do you want do delete this link')">
                                <button class="btn btn-danger">Delete</button>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>

            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\doctorApp\resources\views/admin/view-all-links.blade.php ENDPATH**/ ?>